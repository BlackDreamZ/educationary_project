import React from "react";

const NotFoundPage = () => {
    return <h2> Извините, ничего не найдено.. 404..</h2>
}

export default NotFoundPage;