const LinkToPage = (props) => {
    return (
        <a>{props.title}</a>
    )
}

export default LinkToPage;